---
layout: page
title: Contact
tagline: Marty B.
---

I’m a senior software engineer based in Austria (NOT Australia -> no cangaroos!).
I'm coding mostly in Python, sometimes C and Java (Java not voluntary ;-)).

[Go to the Home Page]({{ site.url }}{{ site.baseurl }})
